from django.db import models

class Categoria(models.Model):
    nombre = models.CharField(max_length=100, unique=True, verbose_name="Nombre de la categoria")
    descripcion = models.TextField(blank=True, null=True, verbose_name="Descripcion")

    class Meta:
        verbose_name = "Categoria"
        verbose_name_plural = "Categorias"
        ordering = ['nombre']

    def __str__(self):
        return self.nombre

class LugarPatrimonial(models.Model):
    nombre = models.CharField(max_length=150, verbose_name="Nombre del lugar")
    descripcion = models.TextField(verbose_name="Descripcion detallada")
    ubicacion = models.CharField(max_length=200, verbose_name="Ubicacion o Direccion")
    ano_construccion = models.IntegerField(verbose_name="Año de construccion")
    imagen = models.URLField(max_length=500, verbose_name="URL de la imagen")
    
    categoria = models.ForeignKey(
        Categoria, 
        on_delete=models.CASCADE, 
        related_name='lugares_patrimoniales', 
        verbose_name="Categoría"
    )
    class Meta:
        verbose_name = "Lugar Patrimonial"
        verbose_name_plural = "Lugares Patrimoniales"
        ordering = ['-id']

    def __str__(self):
        return f"{self.nombre} ({self.ano_construccion})"