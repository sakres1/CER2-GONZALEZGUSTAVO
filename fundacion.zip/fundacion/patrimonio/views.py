from django.shortcuts import render, get_object_or_404
from .models import LugarPatrimonial, Categoria

def inicio(request):
    "Página principal con los ultimos registros y acceso al catalogo"
    contexto = {
        'lugares_recientes': LugarPatrimonial.objects.order_by('-id')[:3],
        'categorias': Categoria.objects.all()
    }
    return render(request, 'patrimonio/inicio.html', contexto)


def catalogo(request):
    "RF02 y RF04: Catálogo general y filtrado dinámico por categoría"
    categoria_slug = request.GET.get('categoria')
    
    lugares = LugarPatrimonial.objects.select_related('categoria').all()
    
    if categoria_slug:
        lugares = lugares.filter(categoria_id=categoria_slug)
        
    contexto = {
        'lugares': lugares,
        'categorias': Categoria.objects.all(),
        'categoria_seleccionada': int(categoria_slug) if categoria_slug else None
    }
    return render(request, 'patrimonio/catalogo.html', contexto)


def detalle_lugar(request, pk):
    "Vista individual detallada de un lugar patrimonial especifico"
    lugar_patrimonial = get_object_or_404(LugarPatrimonial, pk=pk)
    
    contexto = {
        'lugar': lugar_patrimonial
    }
    return render(request, 'patrimonio/detalle_lugar.html', contexto)
