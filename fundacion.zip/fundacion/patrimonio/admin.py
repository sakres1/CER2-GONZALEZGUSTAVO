from django.contrib import admin
from .models import Categoria, LugarPatrimonial

@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre', 'descripcion')
    search_fields = ('nombre',)

@admin.register(LugarPatrimonial)
class LugarPatrimonialAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre', 'categoria', 'ubicacion', 'ano_construccion')
    list_filter = ('categoria', 'ano_construccion')
    search_fields = ('nombre', 'ubicacion')