from django.urls import path
from . import views

app_name = 'patrimonio'

urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('catalogo/', views.catalogo, name='catalogo'),
    path('lugar/<int:pk>/', views.detalle_lugar, name='detalle_lugar'),
]