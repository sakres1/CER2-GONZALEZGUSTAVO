
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('patrimonio.urls')),  # Conecta las rutas de la app patrimonio a la raiz
]